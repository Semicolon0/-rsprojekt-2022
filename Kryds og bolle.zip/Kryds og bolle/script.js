let playBoard = {
    state1:"free",
    state2:"free",
    state3:"free",
    state4:"free",
    state5:"free",
    state6:"free",
    state7:"free",
    state8:"free",
    state9:"free"
}

let turn ="X";
let enemyAi=false;

function setup(){
    document.getElementById("board").style.display="none";
    document.getElementById("replay").style.display="none";
}

function vsHuman(){
    document.getElementById("buttons").style.display="none";
    document.getElementById("board").style.display="block";
}

function vsAi(){
    enemyAi=true;
    document.getElementById("buttons").style.display="none";
    document.getElementById("board").style.display="block";
}

function ai(rand){
    rand=Math.floor(Math.random()*8);
    if(rand==0&&playBoard.state1=="free"){
        document.getElementById("square1").innerHTML = "O";
        turn="X";
        playBoard.state1="O";
        win();
        return playBoard.state1;
    } else if(rand==1&&playBoard.state2=="free"){
        document.getElementById("square2").innerHTML = "O";
        turn="X";
        playBoard.state2="O";
        win();
        return playBoard.state2;
    } else if(rand==2&&playBoard.state3=="free"){
        document.getElementById("square3").innerHTML = "O";
        turn="X";
        playBoard.state3="O";
        win();
        return playBoard.state3;
    } else if(rand==3&&playBoard.state4=="free"){
        document.getElementById("square4").innerHTML = "O";
        turn="X";
        playBoard.state4="O";
        win();
        return playBoard.state4;
    } else if(rand==4&&playBoard.state5=="free"){
        document.getElementById("square5").innerHTML = "O";
        turn="X";
        playBoard.state5="O";
        win();
        return playBoard.state5;
    } else if(rand==5&&playBoard.state6=="free"){
        document.getElementById("square6").innerHTML = "O";
        turn="X";
        playBoard.state6="O";
        win();
        return playBoard.state6;
    } else if(rand==6&&playBoard.state7=="free"){
        document.getElementById("square7").innerHTML = "O";
        turn="X";
        playBoard.state7="O";
        return playBoard.state7;
    } else if(rand==7&&playBoard.state8=="free"){
        document.getElementById("square8").innerHTML = "O";
        turn="X";
        playBoard.state8="O";
        return playBoard.state8;
    } else if(rand==8&&state=="free"){
        document.getElementById("square9").innerHTML = "O";
        turn="X";
        playBoard.state9="O";
        win();
        return playBoard.state9;
    } else {
        ai();
    }
}

function Xtest(){
    turn="X";
    console.log(turn);
}

function Otest(){
    turn="O";
    console.log(turn);
}

function win(winText){
    if(playBoard.state1=="X"&&playBoard.state2=="X"&&playBoard.state3=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state1=="X"&&playBoard.state4=="X"&&playBoard.state7=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state1=="X"&&playBoard.state5=="X"&&playBoard.state9=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state2=="X"&&playBoard.state5=="X"&&playBoard.state8=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state3=="X"&&playBoard.state6=="X"&&playBoard.state9=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state3=="X"&&playBoard.state5=="X"&&playBoard.state7=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state4=="X"&&playBoard.state5=="X"&&playBoard.state6=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state7=="X"&&playBoard.state8=="X"&&playBoard.state9=="X"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="X WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    }else if(playBoard.state1=="O"&&playBoard.state2=="O"&&playBoard.state3=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state1=="O"&&playBoard.state4=="O"&&playBoard.state7=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state1=="O"&&playBoard.state5=="O"&&playBoard.state9=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state2=="O"&&playBoard.state5=="O"&&playBoard.state8=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state3=="O"&&playBoard.state6=="O"&&playBoard.state9=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state3=="O"&&playBoard.state5=="O"&&playBoard.state7=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state4=="O"&&playBoard.state5=="O"&&playBoard.state6=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state7=="O"&&playBoard.state8=="O"&&playBoard.state9=="O"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="O WINS!";
        document.getElementById("winText").style.display="block";
        document.getElementById("replay").style.display="block";
    } else if(playBoard.state1!="free"&&playBoard.state2!="free"&&playBoard.state3!="free"&&playBoard.state4!="free"&&playBoard.state5!="free"&&playBoard.state6!="free"&&playBoard.state7!="free"&&playBoard.state8!="free"&&playBoard.state9!="free"){
        document.getElementById("board").style.display="none";
        document.getElementById("winText").innerHTML ="TIE!";
        document.getElementById("winText").style.display="block";
        document.getElementById("winText").style.left="43%";
        document.getElementById("replay").style.display="block";
    }else if(enemyAi==true&&turn=="O"){
        console.log("ai");
        setTimeout(ai, 500);
    }
}

function replay(){
    turn="X";
    document.getElementById("replay").style.display="none";
    document.getElementById("winText").style.display="none";
    document.getElementById("board").style.display="block";
    document.getElementById("square1").innerHTML="";
    playBoard.state1="free";
    document.getElementById("square2").innerHTML="";
    playBoard.state2="free";
    document.getElementById("square3").innerHTML="";
    playBoard.state3="free";
    document.getElementById("square4").innerHTML="";
    playBoard.state4="free";
    document.getElementById("square5").innerHTML="";
    playBoard.state5="free";
    document.getElementById("square6").innerHTML="";
    playBoard.state6="free";
    document.getElementById("square7").innerHTML="";
    playBoard.state7="free";
    document.getElementById("square8").innerHTML="";
    playBoard.state8="free";
    document.getElementById("square9").innerHTML="";
    playBoard.state9="free";
}


function space1(value){
    if(playBoard.state1=="free"){
        if(turn=="X"){
            document.getElementById("square1").innerHTML = "X";
            turn="O";
            playBoard.state1="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square1").innerHTML = "O";
            turn="X";
            playBoard.state1="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space2(value){
    if(playBoard.state2=="free"){
        if(turn=="X"){
            document.getElementById("square2").innerHTML = "X";
            turn="O";
            playBoard.state2="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square2").innerHTML = "O";
            turn="X";
            playBoard.state2="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}


function space3(value){
    if(playBoard.state3=="free"){
        if(turn=="X"){
            document.getElementById("square3").innerHTML = "X";
            turn="O";
            playBoard.state3="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square3").innerHTML = "O";
            turn="X";
            playBoard.state3="o";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space4(value){
    if(playBoard.state4=="free"){
        if(turn=="X"){
            document.getElementById("square4").innerHTML = "X";
            turn="O";
            playBoard.state4="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square4").innerHTML = "O";
            turn="X";
            playBoard.state4="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space5(value){
    if(playBoard.state5=="free"){
        if(turn=="X"){
            document.getElementById("square5").innerHTML = "X";
            turn="O";
            playBoard.state5="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square5").innerHTML = "O";
            turn="X";
            playBoard.state5="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space6(value){
    if(playBoard.state6=="free"){
        if(turn=="X"){
            document.getElementById("square6").innerHTML = "X";
            turn="O";
            playBoard.state6="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square6").innerHTML = "O";
            turn="X";
            playBoard.state6="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space7(value){
    if(playBoard.state7=="free"){
        if(turn=="X"){
            document.getElementById("square7").innerHTML = "X";
            turn="O";
            playBoard.state7="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square7").innerHTML = "O";
            turn="X";
            playBoard.state7="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space8(value){
    if(playBoard.state8=="free"){
        if(turn=="X"){
            document.getElementById("square8").innerHTML = "X";
            turn="O";
            playBoard.state8="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square8").innerHTML = "O";
            turn="X";
            playBoard.state8="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}

function space9(value){
    if(playBoard.state9=="free"){
        if(turn=="X"){
            document.getElementById("square9").innerHTML = "X";
            turn="O";
            playBoard.state9="X"
            value ="X";
            win();
            return value;
        } else {
            document.getElementById("square9").innerHTML = "O";
            turn="X";
            playBoard.state9="O";
            value="O";
            win();
            return value;
        }
    } else {
        alert("that space has already been taken");
        return;
    }
}